# This is the exception report from lesson 34.
# Comment like a pro.
# Import any required libraries
import FormatValues as FV
import datetime
Today = datetime.datetime.now()
TodayDsp = datetime.datetime.strftime(Today, "%Y-%m-%d")
# Define any program constants (Maybe in a file)
# Process to follow when generating a report.
# Print main headings and column headings.
print()
print("THE COMPANY NAME")
print(f"OVER LIMIT REPORT AS OF {TodayDsp:<10s}")
print()
print("CUSTOMER      CUSTOMER         PHONE       CREDIT     AMOUNT        NEXT      PAYMENT")
print(" NUMBER         NAME           NUMBER      LIMIT       OVER       PAY DATE      DUE")
print("======================================================================================")
# Initialize counters and accumulators for summary / analytics.
CustOverCtr = 0
PayDueAcc = 0
# Open the file with the "r" mode for read.
f = open("CustExtra.dat", "r")
# Set up the loop to process all the records in the file.
for CustRecord in f:      
    # Input - read the first record and split into a list.
    CustLst = CustRecord.split(",")
   
    #Assign variables to each item in the list that are required in the report.
    # The .strip() method removes any spaces in the front or back of a value.
    CustNum = CustLst[0].strip()
    CustName = CustLst[1].strip()
    Phone = CustLst[2].strip()
    BalDue = float(CustLst[3].strip())
    CredLim = float(CustLst[4].strip())
    NextPayDate = CustLst[9].strip()
    NextPayDate = datetime.datetime.strptime(NextPayDate, "%Y-%m-%d")
    # For an exception report, place an if before the calculations that defines the exception.
    if BalDue > CredLim:
        # Perform any required calculations.  In this report, none are necessary.
        AmtOver = BalDue - CredLim
        PayDue = (CredLim * .05) + AmtOver
        # Print the detail line.  A detail line is the details of the record you want.
        NextPayDateDsp = datetime.datetime.strftime(NextPayDate, "%Y-%m-%d")
        print(f"{CustNum:<6s} {CustName:<20s} {Phone:>12s}  {FV.FDollar2(CredLim):>9s} {FV.FDollar2(AmtOver):>9s}  {NextPayDateDsp:>12s}  {FV.FDollar2(PayDue):>9s}")
        # Increment and Accumulate the summary / analytics data.
        CustOverCtr += 1
        PayDueAcc += PayDue
# Close the file.
f.close()
# Print the summary / analytics data.
print("======================================================================================")
print(f"Total customers: {CustOverCtr:>3d}                                                        {FV.FDollar2(PayDueAcc):>10s}")
print()