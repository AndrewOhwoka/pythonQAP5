# Comment
# Program is to create an exceptional insurance 
# policy report for One Stop Insurance Company
# Date written: Dec. 03rd, 2023 - Dec. 07th, 2023
# Author: Andrew Ohwoka

# Import any required libraries
import FormatValues as FV
import datetime
Today = datetime.datetime.now()
TodayDsp = datetime.datetime.strftime(Today, "%Y-%m-%d")
# Define any program constants (Maybe in a file)
NEXT_POLICY_NUMBER = 2032
BASIC_PREMIUM = 869.00
DISCOUNT_FOR_ADDITIONAL_CARS = 0.25
COST_OF_EXTRA_LIABILITY_COVERAGE = 130.00
COST_OF_GLASS_COVERAGE = 86.00
COST_FOR_LOANER_CAR_COVERAGE = 58.00
HST_RATE = 0.15
PROCESSING_FEE_FOR_MONTHLY_PAYMENTS = 39.99
# Process to follow when generating a report.
# Print main headings and column headings.
print()
print("ONE STOP INSURANCE COMPANY")
print(f"POLICY LISTING AS OF {TodayDsp:<10s}")
print()
print("POLICY  CUSTOMER              TOTAL              TOTAL       DOWN      MONTHLY")
print("NUMBER  NAME                 PREMIUM     HST     COSTS      PAYMENT    PAYMENT")
print("==============================================================================")
# Initialize counters and accumulators for summary / analytics.
CustCtr = 0
TotPremAcc = 0
HstAcc = 0
TotCostsAcc = 0
DownPayAcc = 0
MontPayAcc = 0
# Open the file with the "r" mode for read.
f = open("Policies.dat", "r")
# Set up the loop to process all the records in the file.
for CustRecord in f:      
    # Input - read the first record and split into a list.
    CustLst = CustRecord.split(",")
   
    #Assign variables to each item in the list that are required in the report.
    # The .strip() method removes any spaces in the front or back of a value.
    CustNum = CustLst[0].strip()
    PolicyDate = CustLst[1].strip()
    PolicyDate = datetime.datetime.strptime(PolicyDate, "%Y-%m-%d")
    CustFirstName = CustLst[2].strip()
    CustLastName = CustLst[3].strip()
    Street=CustLst[4].strip()
    City = CustLst[5].strip()
    Province = CustLst[6].strip()
    PostalCode = CustLst[7].strip()
    PhoneNum = CustLst[8].strip()
    NumCars = int(CustLst[9].strip())
    ExtraLiability = CustLst[10].strip()
    GlassCoverage = CustLst[11].strip()
    LoanerCar = CustLst[12].strip()
    PaymentOpt = CustLst[13].strip()
    DownPayment = float(CustLst[14].strip())
   
    # For an exception report, place an if before the calculations that defines the exception.
    if PaymentOpt == "Monthly" or DownPayment > 0:
        # Perform any required calculations.  In this report, none are necessary.

        #There will always be one car - then you can check if there are aditional cars.
        InsurancePremium = BASIC_PREMIUM
        if NumCars >= 2:
            additionalCarsPremium = BASIC_PREMIUM * ((1 - DISCOUNT_FOR_ADDITIONAL_CARS) * (NumCars - 1))
            InsurancePremium += additionalCarsPremium # InsurancePremium = InsurancePremium + additionalCarsPremium
 
        TotalExtraCosts = 0
        if ExtraLiability == 'Y':
            TotalExtraCosts += COST_OF_EXTRA_LIABILITY_COVERAGE * NumCars
    
        if GlassCoverage == 'Y':
            TotalExtraCosts += COST_OF_GLASS_COVERAGE * NumCars
    
        if LoanerCar == 'Y':
            TotalExtraCosts = COST_FOR_LOANER_CAR_COVERAGE * NumCars
 
        TotalPremium = InsurancePremium + TotalExtraCosts
        Hst= HST_RATE * TotalPremium
        TotalCost = TotalPremium + Hst
        
        MonthlyPayment = (TotalCost + PROCESSING_FEE_FOR_MONTHLY_PAYMENTS - DownPayment)/ 12
    
        CustName = CustFirstName + " " + CustLastName
        
        print(f"{CustNum:<6s}{CustName:<20s} {FV.FDollar2(TotalPremium):>9s}   {FV.FDollar2(Hst):>7s} {FV.FDollar2(TotalCost):>9s} {FV.FDollar2(DownPayment):>9s}   {FV.FDollar2(MonthlyPayment):>9s} ")
        
        # Increment and Accumulate the summary / analytics data.
        CustCtr += 1
        TotPremAcc += TotalPremium
        HstAcc += Hst
        TotCostsAcc += TotalCost
        DownPayAcc += DownPayment
        MontPayAcc += MonthlyPayment
        
# Close the file.
f.close()
# Print the summary / analytics data.
print("==============================================================================")
print(f"Total policies: {CustCtr:>3d}        {FV.FDollar2(TotPremAcc):>9s} {FV.FDollar2(HstAcc):>7s} {FV.FDollar2(TotCostsAcc):>9s} {FV.FDollar2(DownPayAcc):>9s}   {FV.FDollar2(MontPayAcc):>9s}")    
print()

